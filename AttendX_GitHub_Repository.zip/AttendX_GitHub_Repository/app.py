from flask import Flask, request, redirect, session, render_template_string, flash, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime
import sqlite3
import os

app = Flask(__name__)
app.secret_key = os.environ.get("ATTENDX_SECRET", "attendx-dev-key-change-before-real-use")
DB_NAME = "attendx_v2.db"


def get_db():
    db = sqlite3.connect(DB_NAME)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('student','teacher')),
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        code TEXT NOT NULL,
        teacher_id INTEGER NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS enrollments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL REFERENCES users(id),
        subject_id INTEGER NOT NULL REFERENCES subjects(id),
        UNIQUE(student_id, subject_id)
    );
    CREATE TABLE IF NOT EXISTS attendance_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL REFERENCES subjects(id),
        teacher_id INTEGER NOT NULL REFERENCES users(id),
        session_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'open',
        created_at TEXT NOT NULL,
        closed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS attendance_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL REFERENCES attendance_sessions(id),
        student_id INTEGER NOT NULL REFERENCES users(id),
        status TEXT NOT NULL DEFAULT 'Pending',
        marked_at TEXT,
        updated_at TEXT,
        UNIQUE(session_id, student_id)
    );
    CREATE TABLE IF NOT EXISTS attendance_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        record_id INTEGER NOT NULL REFERENCES attendance_records(id),
        teacher_id INTEGER NOT NULL REFERENCES users(id),
        old_status TEXT NOT NULL,
        new_status TEXT NOT NULL,
        reason TEXT NOT NULL,
        changed_at TEXT NOT NULL
    );
    """)
    db.commit()
    db.close()


STYLE = """
<style>
:root{--blue:#1769aa;--navy:#102a43;--light:#eaf4ff;--bg:#f4f8fc;--green:#16834a;--red:#c62828}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--navy);font-family:Arial,sans-serif}
header{background:var(--navy);color:white;padding:16px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}
header a{color:white;text-decoration:none;margin-right:10px}.brand{font-size:23px;font-weight:bold}
.container{width:95%;max-width:1000px;margin:22px auto}.card{background:white;padding:18px;margin-bottom:16px;border:1px solid #d8e7f5;border-radius:12px;box-shadow:0 3px 12px #102a430d}
h1,h2,h3{color:var(--navy)}input,select{width:100%;padding:11px;margin:6px 0 12px;border:1px solid #cbd8e5;border-radius:7px;font-size:15px;background:white}
button,.btn{display:inline-block;background:var(--blue);color:white;padding:10px 14px;border:0;border-radius:7px;text-decoration:none;cursor:pointer;margin:3px 0;font-size:14px}
.green{background:var(--green)}.red{background:var(--red)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}
table{width:100%;border-collapse:collapse;background:white}th,td{padding:10px;border-bottom:1px solid #e1e9f0;text-align:left;font-size:14px}th{background:var(--light)}.table-wrap{overflow-x:auto}
.badge{padding:5px 8px;border-radius:12px;font-size:12px;font-weight:bold}.Present{color:#087443;background:#d8f5e5}.Absent{color:#b71c1c;background:#ffdfdf}.Pending{color:#8a5b00;background:#fff0c2}
.flash{padding:12px;margin-bottom:10px;background:#fff0c2;border-radius:7px}.muted{color:#627d98;font-size:13px}footer{text-align:center;color:#627d98;padding:18px}
</style>
"""

LAYOUT = """
<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ title }} | AttendX</title>""" + STYLE + """</head><body>
<header><div class="brand">🌊 AttendX</div><nav>
{% if user %}<span>{{ user.full_name }}</span> · <a href="{{ url_for('dashboard') }}">Home</a><a href="{{ url_for('logout') }}">Logout</a>
{% else %}<a href="{{ url_for('login') }}">Login</a><a href="{{ url_for('register') }}">Register</a>{% endif %}
</nav></header><main class="container">
{% with messages = get_flashed_messages() %}{% for message in messages %}<div class="flash">{{ message }}</div>{% endfor %}{% endwith %}
{{ content|safe }}</main><footer>AttendX — Smart Attendance Platform</footer></body></html>
"""


def page(title, content, **values):
    user = None
    if session.get("user_id"):
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
        db.close()
    inner = render_template_string(content, **values)
    return render_template_string(LAYOUT, title=title, content=inner, user=user)


def login_required(role=None):
    def decorator(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            uid = session.get("user_id")
            if not uid:
                flash("Please log in first.")
                return redirect(url_for("login"))
            db = get_db()
            user = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
            db.close()
            if not user:
                session.clear()
                flash("Account not found. Please log in again.")
                return redirect(url_for("login"))
            if role and user["role"] != role:
                flash("You do not have permission to access that page.")
                return redirect(url_for("dashboard"))
            return func(*args, **kwargs)
        return wrapped
    return decorator


@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return page("Welcome", """
    <div class="card"><h1>Welcome to AttendX 🌊</h1><h3>Your Smart Attendance Platform</h3>
    <p>Manage subjects, attendance sessions and class registers.</p>
    <a class="btn" href="{{ url_for('login') }}">Login</a>
    <a class="btn green" href="{{ url_for('register') }}">Create Account</a></div>
    <div class="grid"><div class="card"><h3>📚 Subjects</h3>Manage subjects and enrollment.</div>
    <div class="card"><h3>✅ Attendance</h3>Track Present, Absent and Pending.</div>
    <div class="card"><h3>📊 Reports</h3>View subject-wise percentages.</div></div>
    """)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("full_name", "").strip()
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "student")
        if not name or not username or not password:
            flash("Fill in all fields.")
            return redirect(url_for("register"))
        if len(password) < 6:
            flash("Password must be at least 6 characters.")
            return redirect(url_for("register"))
        if role not in ("student", "teacher"):
            flash("Invalid account type.")
            return redirect(url_for("register"))
        db = get_db()
        try:
            db.execute("INSERT INTO users(full_name,username,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                       (name, username, generate_password_hash(password), role, now()))
            db.commit()
            flash("Account created. Please log in.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That username already exists.")
        finally:
            db.close()
        return redirect(url_for("register"))
    return page("Register", """
    <div class="card"><h2>Create Account</h2>
    <form method="post" action="{{ url_for('register') }}">
    <label>Full name</label><input name="full_name" required maxlength="100">
    <label>Username</label><input name="username" required maxlength="50">
    <label>Password (minimum 6 characters)</label><input type="password" name="password" minlength="6" required>
    <label>Account type</label><select name="role"><option value="student">Student</option><option value="teacher">Teacher</option></select>
    <button type="submit">Create Account</button></form>
    <p>Already registered? <a href="{{ url_for('login') }}">Login</a></p>
    <p class="muted">Prototype: teacher accounts are not verified. Do not use for real college records.</p></div>
    """)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        db.close()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["role"] = user["role"]
            flash("Welcome, " + user["full_name"] + "!")
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.")
        return redirect(url_for("login"))
    return page("Login", """
    <div class="card"><h2>Login to AttendX</h2>
    <form method="post" action="{{ url_for('login') }}">
    <label>Username</label><input name="username" required autocomplete="username">
    <label>Password</label><input type="password" name="password" required autocomplete="current-password">
    <button type="submit">Login</button></form>
    <p>New user? <a href="{{ url_for('register') }}">Create an account</a></p></div>
    """)


@app.route("/logout")
def logout():
    session.clear()
    flash("You have logged out.")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required()
def dashboard():
    if session.get("role") == "teacher":
        return redirect(url_for("teacher"))
    db = get_db()
    uid = session["user_id"]
    subjects = db.execute("""SELECT s.*, u.full_name AS teacher_name FROM enrollments e
        JOIN subjects s ON s.id=e.subject_id JOIN users u ON u.id=s.teacher_id
        WHERE e.student_id=? ORDER BY s.name""", (uid,)).fetchall()
    open_sessions = db.execute("""SELECT a.id,a.session_date,s.name,s.code FROM attendance_sessions a
        JOIN subjects s ON s.id=a.subject_id JOIN enrollments e ON e.subject_id=s.id
        WHERE e.student_id=? AND a.status='open' ORDER BY a.id DESC""", (uid,)).fetchall()
    reports = db.execute("""SELECT s.name, COUNT(ar.id) AS total,
        SUM(CASE WHEN ar.status='Present' THEN 1 ELSE 0 END) AS presents
        FROM attendance_records ar JOIN attendance_sessions a ON a.id=ar.session_id
        JOIN subjects s ON s.id=a.subject_id WHERE ar.student_id=? AND a.status='closed'
        GROUP BY s.id,s.name ORDER BY s.name""", (uid,)).fetchall()
    db.close()
    return page("Student Dashboard", """
    <h1>Student Dashboard 🎓</h1><div class="card"><h2>Open Sessions</h2>
    {% for a in open_sessions %}<div class="card"><h3>{{ a.name }} ({{ a.code }})</h3>
    <p>{{ a.session_date }}</p><a class="btn" href="{{ url_for('mark_attendance', session_id=a.id) }}">Mark Attendance</a></div>
    {% else %}<p>No open sessions for your subjects.</p>{% endfor %}</div>
    <div class="card"><h2>My Subjects</h2><div class="table-wrap"><table><tr><th>Subject</th><th>Code</th><th>Teacher</th></tr>
    {% for s in subjects %}<tr><td>{{ s.name }}</td><td>{{ s.code }}</td><td>{{ s.teacher_name }}</td></tr>{% else %}
    <tr><td colspan="3">Not enrolled in any subjects yet. Ask your teacher to enroll you.</td></tr>{% endfor %}</table></div></div>
    <div class="card"><h2>Attendance Percentage</h2><div class="table-wrap"><table><tr><th>Subject</th><th>Present</th><th>Total</th><th>Percentage</th></tr>
    {% for r in reports %}<tr><td>{{ r.name }}</td><td>{{ r.presents or 0 }}</td><td>{{ r.total }}</td>
    <td>{{ "%.1f"|format(100*(r.presents or 0)/r.total) }}%</td></tr>{% else %}
    <tr><td colspan="4">No closed sessions to report yet.</td></tr>{% endfor %}</table></div></div>
    """, subjects=subjects, open_sessions=open_sessions, reports=reports)


@app.route("/teacher")
@login_required("teacher")
def teacher():
    db = get_db()
    uid = session["user_id"]
    subjects = db.execute("""SELECT s.*,(SELECT COUNT(*) FROM enrollments e WHERE e.subject_id=s.id) AS student_count
        FROM subjects s WHERE s.teacher_id=? ORDER BY s.name""", (uid,)).fetchall()
    students = db.execute("SELECT id,full_name,username FROM users WHERE role='student' ORDER BY full_name").fetchall()
    sessions = db.execute("""SELECT a.*,s.name AS subject_name,s.code FROM attendance_sessions a
        JOIN subjects s ON s.id=a.subject_id WHERE a.teacher_id=? ORDER BY a.id DESC LIMIT 30""", (uid,)).fetchall()
    db.close()
    return page("Teacher Dashboard", """
    <h1>Teacher Dashboard 👨‍🏫</h1>
    <div class="card"><h2>Advanced Reports</h2>
    <p>Review subject attendance, student percentages and students below 75%.</p>
    <a class="btn" href="{{ url_for('attendance_reports') }}">Open Attendance Reports</a></div>
    <div class="card"><h2>Create Subject</h2>
    <form method="post" action="{{ url_for('create_subject') }}"><label>Subject name</label><input name="name" required>
    <label>Subject code</label><input name="code" required><button>Create Subject</button></form></div>
    <div class="card"><h2>My Subjects</h2>{% for s in subjects %}<div class="card"><h3>{{ s.name }} — {{ s.code }}</h3>
    <p>Enrolled students: {{ s.student_count }}</p><a class="btn" href="{{ url_for('manage_enrollment', subject_id=s.id) }}">Manage Enrollment</a>
    <form method="post" action="{{ url_for('open_session') }}"><input type="hidden" name="subject_id" value="{{ s.id }}">
    <button type="submit">Open Attendance</button></form></div>{% else %}<p>Create your first subject above.</p>{% endfor %}</div>
    <div class="card"><h2>Attendance Sessions</h2><div class="table-wrap"><table><tr><th>Subject</th><th>Date</th><th>Status</th><th>Register</th></tr>
    {% for a in sessions %}<tr><td>{{ a.subject_name }} ({{ a.code }})</td><td>{{ a.session_date }}</td><td>{{ a.status|capitalize }}</td>
    <td><a class="btn" href="{{ url_for('session_register', session_id=a.id) }}">Open Register</a></td></tr>{% else %}
    <tr><td colspan="4">No sessions yet.</td></tr>{% endfor %}</table></div></div>
    <div class="card"><h2>Student Accounts ({{ students|length }})</h2><div class="table-wrap"><table><tr><th>Name</th><th>Username</th></tr>
    {% for st in students %}<tr><td>{{ st.full_name }}</td><td>{{ st.username }}</td></tr>{% else %}
    <tr><td colspan="2">No student accounts yet.</td></tr>{% endfor %}</table></div></div>
    """, subjects=subjects, students=students, sessions=sessions)


@app.route("/subject", methods=["POST"])
@login_required("teacher")
def create_subject():
    name = request.form.get("name", "").strip()
    code = request.form.get("code", "").strip().upper()
    if not name or not code:
        flash("Enter subject name and code.")
        return redirect(url_for("teacher"))
    db = get_db()
    db.execute("INSERT INTO subjects(name,code,teacher_id,created_at) VALUES(?,?,?,?)",
               (name, code, session["user_id"], now()))
    db.commit()
    db.close()
    flash("Subject created.")
    return redirect(url_for("teacher"))


@app.route("/subject/<int:subject_id>/enrollment", methods=["GET", "POST"])
@login_required("teacher")
def manage_enrollment(subject_id):
    db = get_db()
    subject = db.execute("SELECT * FROM subjects WHERE id=? AND teacher_id=?",
                         (subject_id, session["user_id"])).fetchone()
    if not subject:
        db.close()
        flash("Subject not found or access denied.")
        return redirect(url_for("teacher"))
    if request.method == "POST":
        student_id = request.form.get("student_id", type=int)
        student = db.execute("SELECT id FROM users WHERE id=? AND role='student'", (student_id,)).fetchone()
        if not student:
            db.close()
            flash("Select a valid student.")
            return redirect(url_for("manage_enrollment", subject_id=subject_id))
        try:
            db.execute("INSERT INTO enrollments(student_id,subject_id) VALUES(?,?)", (student_id, subject_id))
            db.commit()
            flash("Student enrolled.")
        except sqlite3.IntegrityError:
            flash("Student is already enrolled.")
        db.close()
        return redirect(url_for("manage_enrollment", subject_id=subject_id))
    available = db.execute("""SELECT id,full_name,username FROM users WHERE role='student'
        AND id NOT IN (SELECT student_id FROM enrollments WHERE subject_id=?) ORDER BY full_name""",
        (subject_id,)).fetchall()
    enrolled = db.execute("""SELECT u.id,u.full_name,u.username FROM enrollments e JOIN users u ON u.id=e.student_id
        WHERE e.subject_id=? ORDER BY u.full_name""", (subject_id,)).fetchall()
    db.close()
    return page("Manage Enrollment", """
    <div class="card"><h2>{{ subject.name }} ({{ subject.code }})</h2><form method="post"
    action="{{ url_for('manage_enrollment', subject_id=subject.id) }}"><label>Student to enroll</label>
    <select name="student_id" required><option value="">Choose a student</option>
    {% for s in available %}<option value="{{ s.id }}">{{ s.full_name }} ({{ s.username }})</option>{% endfor %}</select>
    <button type="submit">Enroll Student</button></form>{% if not available %}<p>No available student accounts.</p>{% endif %}</div>
    <div class="card"><h2>Enrolled Students</h2><div class="table-wrap"><table><tr><th>Name</th><th>Username</th></tr>
    {% for s in enrolled %}<tr><td>{{ s.full_name }}</td><td>{{ s.username }}</td></tr>{% else %}
    <tr><td colspan="2">No students enrolled yet.</td></tr>{% endfor %}</table></div></div>
    <a class="btn" href="{{ url_for('teacher') }}">Back</a>
    """, subject=subject, available=available, enrolled=enrolled)


@app.route("/open-session", methods=["POST"])
@login_required("teacher")
def open_session():
    subject_id = request.form.get("subject_id", type=int)
    db = get_db()
    subject = db.execute("SELECT * FROM subjects WHERE id=? AND teacher_id=?",
                         (subject_id, session["user_id"])).fetchone()
    if not subject:
        db.close()
        flash("Subject not found or access denied.")
        return redirect(url_for("teacher"))
    students = db.execute("SELECT student_id FROM enrollments WHERE subject_id=?", (subject_id,)).fetchall()
    if not students:
        db.close()
        flash("Enroll students before opening attendance.")
        return redirect(url_for("teacher"))
    existing = db.execute("SELECT id FROM attendance_sessions WHERE subject_id=? AND status='open'",
                           (subject_id,)).fetchone()
    if existing:
        db.close()
        flash("This subject already has an open session.")
        return redirect(url_for("session_register", session_id=existing["id"]))
    cur = db.execute("""INSERT INTO attendance_sessions(subject_id,teacher_id,session_date,status,created_at)
        VALUES(?,?,?,'open',?)""",
        (subject_id, session["user_id"], datetime.now().strftime("%Y-%m-%d"), now()))
    sid = cur.lastrowid
    for st in students:
        db.execute("INSERT INTO attendance_records(session_id,student_id,status) VALUES(?,?,'Pending')",
                   (sid, st["student_id"]))
    db.commit()
    db.close()
    flash("Attendance session opened.")
    return redirect(url_for("session_register", session_id=sid))


@app.route("/mark/<int:session_id>", methods=["GET", "POST"])
@login_required("student")
def mark_attendance(session_id):
    db = get_db()
    att = db.execute("""SELECT a.*,s.name AS subject_name,s.code FROM attendance_sessions a
        JOIN subjects s ON s.id=a.subject_id JOIN enrollments e ON e.subject_id=s.id
        WHERE a.id=? AND e.student_id=?""", (session_id, session["user_id"])).fetchone()
    record = db.execute("SELECT * FROM attendance_records WHERE session_id=? AND student_id=?",
                        (session_id, session["user_id"])).fetchone()
    if not att or not record:
        db.close()
        flash("Session not found or you are not enrolled.")
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        if att["status"] != "open" or record["status"] != "Pending":
            db.close()
            flash("Attendance cannot be marked now.")
            return redirect(url_for("dashboard"))
        db.execute("UPDATE attendance_records SET status='Present',marked_at=?,updated_at=? WHERE id=?",
                   (now(), now(), record["id"]))
        db.commit()
        db.close()
        flash("Attendance marked Present.")
        return redirect(url_for("dashboard"))
    db.close()
    return page("Mark Attendance", """
    <div class="card"><h2>Confirm Attendance</h2><h3>{{ att.subject_name }} ({{ att.code }})</h3>
    <p>Date: {{ att.session_date }}</p><p>Status: <span class="badge {{ record.status }}">{{ record.status }}</span></p>
    {% if att.status == 'open' and record.status == 'Pending' %}
    <p>Only confirm if you are physically present in class.</p>
    <form method="post" action="{{ url_for('mark_attendance', session_id=att.id) }}"><button class="green">Confirm Present</button></form>
    {% else %}<p>Attendance cannot be marked for this session.</p>{% endif %}
    <a class="btn" href="{{ url_for('dashboard') }}">Back</a></div>
    """, att=att, record=record)


@app.route("/session/<int:session_id>")
@login_required("teacher")
def session_register(session_id):
    db = get_db()
    att = db.execute("""SELECT a.*,s.name AS subject_name,s.code FROM attendance_sessions a
        JOIN subjects s ON s.id=a.subject_id WHERE a.id=? AND a.teacher_id=?""",
        (session_id, session["user_id"])).fetchone()
    if not att:
        db.close()
        flash("Session not found or access denied.")
        return redirect(url_for("teacher"))
    records = db.execute("""SELECT ar.id AS record_id,ar.status,ar.marked_at,u.full_name,u.username
        FROM attendance_records ar JOIN users u ON u.id=ar.student_id
        WHERE ar.session_id=? ORDER BY u.full_name""", (session_id,)).fetchall()
    counts = db.execute("""SELECT SUM(status='Present') AS present,SUM(status='Absent') AS absent,
        SUM(status='Pending') AS pending FROM attendance_records WHERE session_id=?""", (session_id,)).fetchone()
    db.close()
    return page("Attendance Register", """
    <div class="card"><h1>Attendance Register</h1><h2>{{ att.subject_name }} ({{ att.code }})</h2>
    <p>Date: {{ att.session_date }} · Session: {{ att.status|capitalize }}</p>
    <div class="grid"><div class="card">Present: {{ counts.present or 0 }}</div>
    <div class="card">Absent: {{ counts.absent or 0 }}</div><div class="card">Pending: {{ counts.pending or 0 }}</div></div></div>
    <div class="card"><h2>All Enrolled Students</h2><div class="table-wrap"><table>
    <tr><th>Name</th><th>Username</th><th>Status</th><th>Change status</th></tr>
    {% for r in records %}<tr><td>{{ r.full_name }}</td><td>{{ r.username }}</td>
    <td><span class="badge {{ r.status }}">{{ r.status }}</span></td><td>
    {% if att.status == 'open' %}<form method="post" action="{{ url_for('correct_attendance', record_id=r.record_id) }}">
    <select name="status"><option value="Present" {% if r.status=='Present' %}selected{% endif %}>Present</option>
    <option value="Absent" {% if r.status=='Absent' %}selected{% endif %}>Absent</option>
    <option value="Pending" {% if r.status=='Pending' %}selected{% endif %}>Pending</option></select>
    <input name="reason" maxlength="250" placeholder="Reason for change" required><button>Save</button></form>
    {% else %}<span class="muted">Session closed</span>{% endif %}</td></tr>
    {% else %}<tr><td colspan="4">No student records.</td></tr>{% endfor %}</table></div></div>
    {% if att.status == 'open' %}<div class="card"><h2>Close Session</h2>
    <p>All remaining Pending students will be marked Absent.</p>
    <form method="post" action="{{ url_for('close_session', session_id=att.id) }}"><button class="red">Close Session</button></form></div>{% endif %}
    <div class="card"><a class="btn" href="{{ url_for('audit_history', session_id=att.id) }}">View Correction History</a>
    <a class="btn" href="{{ url_for('teacher') }}">Teacher Dashboard</a></div>
    """, att=att, records=records, counts=counts)


@app.route("/correct/<int:record_id>", methods=["POST"])
@login_required("teacher")
def correct_attendance(record_id):
    new_status = request.form.get("status", "")
    reason = request.form.get("reason", "").strip()
    if new_status not in ("Present", "Absent", "Pending") or not reason:
        flash("Choose a valid status and enter a reason.")
        return redirect(url_for("teacher"))
    db = get_db()
    rec = db.execute("""SELECT ar.*,a.teacher_id,a.status AS session_status FROM attendance_records ar
        JOIN attendance_sessions a ON a.id=ar.session_id WHERE ar.id=?""", (record_id,)).fetchone()
    if not rec or rec["teacher_id"] != session["user_id"]:
        db.close()
        flash("Record not found or access denied.")
        return redirect(url_for("teacher"))
    if rec["session_status"] != "open":
        db.close()
        flash("Closed-session corrections are disabled in this version.")
        return redirect(url_for("session_register", session_id=rec["session_id"]))
    old_status = rec["status"]
    if old_status == new_status:
        db.close()
        flash("No change was made.")
        return redirect(url_for("session_register", session_id=rec["session_id"]))
    db.execute("UPDATE attendance_records SET status=?,updated_at=? WHERE id=?", (new_status, now(), record_id))
    db.execute("""INSERT INTO attendance_audit(record_id,teacher_id,old_status,new_status,reason,changed_at)
        VALUES(?,?,?,?,?,?)""", (record_id, session["user_id"], old_status, new_status, reason, now()))
    db.commit()
    db.close()
    flash("Attendance updated and correction history saved.")
    return redirect(url_for("session_register", session_id=rec["session_id"]))


@app.route("/close-session/<int:session_id>", methods=["POST"])
@login_required("teacher")
def close_session(session_id):
    db = get_db()
    att = db.execute("SELECT * FROM attendance_sessions WHERE id=? AND teacher_id=?",
                     (session_id, session["user_id"])).fetchone()
    if not att:
        db.close()
        flash("Session not found or access denied.")
        return redirect(url_for("teacher"))
    if att["status"] == "closed":
        db.close()
        flash("Session is already closed.")
        return redirect(url_for("session_register", session_id=session_id))
    db.execute("UPDATE attendance_records SET status='Absent',updated_at=? WHERE session_id=? AND status='Pending'",
               (now(), session_id))
    db.execute("UPDATE attendance_sessions SET status='closed',closed_at=? WHERE id=?", (now(), session_id))
    db.commit()
    db.close()
    flash("Session closed. Remaining Pending students are now Absent.")
    return redirect(url_for("session_register", session_id=session_id))


@app.route("/audit/<int:session_id>")
@login_required("teacher")
def audit_history(session_id):
    db = get_db()
    att = db.execute("SELECT * FROM attendance_sessions WHERE id=? AND teacher_id=?",
                     (session_id, session["user_id"])).fetchone()
    if not att:
        db.close()
        flash("Session not found or access denied.")
        return redirect(url_for("teacher"))
    history = db.execute("""SELECT au.*,t.full_name AS teacher_name,st.full_name AS student_name
        FROM attendance_audit au JOIN attendance_records ar ON ar.id=au.record_id
        JOIN users t ON t.id=au.teacher_id JOIN users st ON st.id=ar.student_id
        WHERE ar.session_id=? ORDER BY au.id DESC""", (session_id,)).fetchall()
    db.close()
    return page("Correction History", """
    <div class="card"><h2>Attendance Correction History</h2><div class="table-wrap"><table>
    <tr><th>Student</th><th>Old</th><th>New</th><th>Reason</th><th>Teacher</th><th>Time</th></tr>
    {% for h in history %}<tr><td>{{ h.student_name }}</td><td>{{ h.old_status }}</td><td>{{ h.new_status }}</td>
    <td>{{ h.reason }}</td><td>{{ h.teacher_name }}</td><td>{{ h.changed_at }}</td></tr>
    {% else %}<tr><td colspan="6">No corrections recorded.</td></tr>{% endfor %}
    </table></div><a class="btn" href="{{ url_for('session_register', session_id=att.id) }}">Back to Register</a></div>
    """, history=history, att=att)


@app.route("/reports")
@login_required("teacher")
def attendance_reports():
    selected_subject = request.args.get("subject_id", type=int)
    db = get_db()
    teacher_id = session["user_id"]

    subjects = db.execute(
        "SELECT id, name, code FROM subjects WHERE teacher_id=? ORDER BY name",
        (teacher_id,)
    ).fetchall()

    allowed_ids = {row["id"] for row in subjects}
    if selected_subject not in allowed_ids:
        selected_subject = None

    overall = db.execute("""
        SELECT COUNT(ar.id) AS total_records,
               SUM(CASE WHEN ar.status='Present' THEN 1 ELSE 0 END) AS present_count,
               SUM(CASE WHEN ar.status='Absent' THEN 1 ELSE 0 END) AS absent_count
        FROM attendance_records ar
        JOIN attendance_sessions a ON a.id=ar.session_id
        JOIN subjects s ON s.id=a.subject_id
        WHERE s.teacher_id=? AND a.status='closed'
    """, (teacher_id,)).fetchone()

    subject_reports = db.execute("""
        SELECT s.id, s.name, s.code,
               COUNT(ar.id) AS total,
               SUM(CASE WHEN ar.status='Present' THEN 1 ELSE 0 END) AS presents,
               SUM(CASE WHEN ar.status='Absent' THEN 1 ELSE 0 END) AS absents
        FROM subjects s
        LEFT JOIN attendance_sessions a ON a.subject_id=s.id AND a.status='closed'
        LEFT JOIN attendance_records ar ON ar.session_id=a.id
        WHERE s.teacher_id=?
        GROUP BY s.id, s.name, s.code
        ORDER BY s.name
    """, (teacher_id,)).fetchall()

    student_sql = """
        SELECT u.id, u.full_name, u.username, s.id AS subject_id,
               s.name AS subject_name, s.code,
               COUNT(ar.id) AS total,
               SUM(CASE WHEN ar.status='Present' THEN 1 ELSE 0 END) AS presents,
               SUM(CASE WHEN ar.status='Absent' THEN 1 ELSE 0 END) AS absents
        FROM enrollments e
        JOIN users u ON u.id=e.student_id
        JOIN subjects s ON s.id=e.subject_id
        LEFT JOIN attendance_sessions a ON a.subject_id=s.id AND a.status='closed'
        LEFT JOIN attendance_records ar ON ar.session_id=a.id AND ar.student_id=u.id
        WHERE s.teacher_id=?
    """
    params = [teacher_id]
    if selected_subject is not None:
        student_sql += " AND s.id=?"
        params.append(selected_subject)
    student_sql += """
        GROUP BY u.id, u.full_name, u.username, s.id, s.name, s.code
        ORDER BY s.name, u.full_name
    """
    student_reports = db.execute(student_sql, params).fetchall()
    db.close()

    overall_total = overall["total_records"] or 0
    overall_present = overall["present_count"] or 0
    overall_absent = overall["absent_count"] or 0
    overall_pct = (100 * overall_present / overall_total) if overall_total else 0

    return page("Advanced Attendance Reports", """
    <h1>📊 Advanced Attendance Reports</h1>
    <div class="grid">
      <div class="card"><h3>Recorded Entries</h3><p>{{ overall_total }}</p></div>
      <div class="card"><h3>Present Entries</h3><p>{{ overall_present }}</p></div>
      <div class="card"><h3>Absent Entries</h3><p>{{ overall_absent }}</p></div>
      <div class="card"><h3>Overall Present Rate</h3><p>{{ "%.1f"|format(overall_pct) }}%</p></div>
    </div>
    <div class="card"><h2>Subject-wise Summary</h2><div class="table-wrap"><table>
      <tr><th>Subject</th><th>Code</th><th>Entries</th><th>Present</th><th>Absent</th><th>Present rate</th></tr>
      {% for r in subject_reports %}
      <tr><td>{{ r.name }}</td><td>{{ r.code }}</td><td>{{ r.total or 0 }}</td>
      <td>{{ r.presents or 0 }}</td><td>{{ r.absents or 0 }}</td>
      <td>{% if r.total %}{{ "%.1f"|format(100*(r.presents or 0)/r.total) }}%{% else %}—{% endif %}</td></tr>
      {% else %}<tr><td colspan="6">No subjects yet.</td></tr>{% endfor %}
    </table></div><p class="muted">Only closed sessions are counted.</p></div>

    <div class="card"><h2>Student Attendance</h2>
      <form method="get" action="{{ url_for('attendance_reports') }}">
        <label>Filter by subject</label>
        <select name="subject_id"><option value="">All subjects</option>
        {% for s in subjects %}<option value="{{ s.id }}" {% if selected_subject == s.id %}selected{% endif %}>
        {{ s.name }} ({{ s.code }})</option>{% endfor %}</select>
        <button type="submit">Apply Filter</button>
        <a class="btn" href="{{ url_for('attendance_reports') }}">Clear</a>
      </form>
      <div class="table-wrap"><table>
      <tr><th>Student</th><th>Username</th><th>Subject</th><th>Present</th><th>Absent</th><th>Total</th><th>Percentage</th><th>Alert</th></tr>
      {% for r in student_reports %}
      <tr><td>{{ r.full_name }}</td><td>{{ r.username }}</td><td>{{ r.subject_name }} ({{ r.code }})</td>
      <td>{{ r.presents or 0 }}</td><td>{{ r.absents or 0 }}</td><td>{{ r.total or 0 }}</td>
      <td>{% if r.total %}{{ "%.1f"|format(100*(r.presents or 0)/r.total) }}%{% else %}—{% endif %}</td>
      <td>{% if r.total and (100*(r.presents or 0)/r.total) < 75 %}
        <span class="badge Absent">Below 75%</span>
      {% elif r.total %}<span class="badge Present">75% or above</span>
      {% else %}<span class="badge Pending">No classes</span>{% endif %}</td></tr>
      {% else %}<tr><td colspan="8">No enrolled students found.</td></tr>{% endfor %}
      </table></div>
      <p class="muted">Percentage = Present classes ÷ closed classes × 100.</p>
    </div>
    <a class="btn" href="{{ url_for('teacher') }}">Back to Teacher Dashboard</a>
    """, subjects=subjects, selected_subject=selected_subject,
       subject_reports=subject_reports, student_reports=student_reports,
       overall_total=overall_total, overall_present=overall_present,
       overall_absent=overall_absent, overall_pct=overall_pct)




# Initialize the database when imported by a WSGI server such as Gunicorn.
init_db()

if __name__ == "__main__":
    init_db()
    print("=" * 40)
    print("AttendX is starting")
    print("Open http://127.0.0.1:5000 in your browser")
    print("=" * 40)
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)
