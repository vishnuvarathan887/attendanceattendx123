const subjects = [
{ name: "Programming in C", attended: 18, total: 20 },
{ name: "Mathematics", attended: 16, total: 20 },
{ name: "Digital Electronics", attended: 17, total: 20 },
{ name: "English", attended: 17, total: 20 }
];

const subjectsContainer = document.getElementById("subjects");

subjects.forEach(function (subject) {
const percentage = Math.round(
(subject.attended / subject.total) * 100
);

const card = document.createElement("article");
card.className = "subject-card";

card.innerHTML = `
    <div class="subject-top">
        <div>
            <h4>${subject.name}</h4>
            <p>${subject.attended} of ${subject.total} classes attended</p>
        </div>
        <span class="subject-percent">${percentage}%</span>
    </div>
    <div class="progress-track">
        <div class="progress-bar" style="width:${percentage}%"></div>
    </div>
`;

subjectsContainer.appendChild(card);

});

document.getElementById("markButton").addEventListener("click", function () {
document.getElementById("markMessage").textContent =
"Demo only: No attendance has been recorded. " +
"We'll connect this button to secure classroom verification later.";
});

document.querySelectorAll(".nav-item").forEach(function (button) {
button.addEventListener("click", function () {
document.querySelectorAll(".nav-item").forEach(function (item) {
item.classList.remove("active");
});

    button.classList.add("active");

    if (button.dataset.page !== "Home") {
        alert(button.dataset.page +
            " will be developed in a future version.");
    }
});

});