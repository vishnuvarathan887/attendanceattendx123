const loginForm = document.getElementById("loginForm");
const message = document.getElementById("message");

loginForm.addEventListener("submit", function (event) {
event.preventDefault();

const role = document.getElementById("role").value;
const collegeId = document.getElementById("collegeId").value.trim();
const userId = document.getElementById("userId").value.trim();
const password = document.getElementById("password").value;

if (!collegeId || !userId || !password) {
    message.textContent = "Please complete all fields.";
    return;
}

message.textContent =
    "Interface test successful! " +
    "The secure " + role +
    " login system will be connected in the next stage.";

});