# AttendX — Attendance Management System

AttendX is a Flask + SQLite attendance-management project with student and teacher roles. The current Python app includes account registration/login, subject and enrollment management, attendance sessions, student attendance marking, teacher attendance corrections, an audit trail, and attendance reports.

## Project structure

```text
AttendX_GitHub_Repository/
├── app.py              # Flask application
├── requirements.txt    # Python dependencies
├── Procfile            # Gunicorn start command for supported hosts
├── frontend/           # Original HTML, CSS and JavaScript files
└── .gitignore
```

> **Frontend note:** The current Flask routes render their pages from templates embedded in `app.py`. The files in `frontend/` are included as the original frontend assets, but they are not automatically connected to those routes yet.

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Set a strong secret key before running the app. Example for macOS/Linux:

   ```bash
   export ATTENDX_SECRET="replace-with-a-long-random-secret"
   ```

   PowerShell:

   ```powershell
   $env:ATTENDX_SECRET="replace-with-a-long-random-secret"
   ```

6. Start the application:

   ```bash
   python app.py
   ```

7. Open `http://127.0.0.1:5000` in your browser.

## Publish to GitHub

1. Create a new repository on GitHub named `AttendX` (or another name you prefer).
2. Extract this ZIP file.
3. Upload the extracted files/folders to the repository, or use Git from your computer.
4. Commit and push the files.

GitHub stores and versions the source code; **it does not run a Flask website by itself**. To make the app publicly accessible, deploy it to a Python-capable host. Configure the host to install `requirements.txt`, run `gunicorn app:app`, and set the `ATTENDX_SECRET` environment variable.

## Deployment and data notes

- The app uses SQLite (`attendx_v2.db`). This database is created at runtime and is intentionally excluded from Git. Some hosting platforms use temporary filesystems, so SQLite data may disappear after restarts or redeploys unless persistent storage is configured.
- Use persistent storage or a managed database before relying on this for real attendance records.
- Do not commit real student data, passwords, secret keys, or database files.
- Teacher accounts are not independently verified by an institution in this project; do not use it for official attendance without adding suitable authorization and security controls.
- The built-in secret-key fallback is only suitable for local development. Set `ATTENDX_SECRET` to a long random value in deployment settings.
- Test registration, login, attendance marking, reports, and database persistence before sharing the deployed site.

## Status

Student project / prototype. Review and security-test before real-world use.
